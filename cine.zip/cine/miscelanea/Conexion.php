<?php

$host = "localhost";
$user = "root";
$password = "";
$db = "proyectocine";

$Conexion = mysqli_connect($host, $user, $password, $db);


?>